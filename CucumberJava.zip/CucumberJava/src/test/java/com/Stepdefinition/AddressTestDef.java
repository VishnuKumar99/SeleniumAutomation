package com.Cucumber.StepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddressTestDef {
	WebDriver driver;
	public static String discountText,text;

	@Before
	public void setUp(){
		System.setProperty("webdriver.gecko.driver", "./geckodriver");
		FirefoxBinary firefoxBinary = new FirefoxBinary();
		firefoxBinary.addCommandLineOptions("--headless");
		FirefoxProfile profile=new FirefoxProfile();
		FirefoxOptions firefoxOptions = new FirefoxOptions();
		firefoxOptions.setBinary(firefoxBinary);
		firefoxOptions.setProfile(profile);
		driver=new FirefoxDriver(firefoxOptions);
		loadURL();
	}
	@Given("^Launch the application$")
	public void loadURL() {
		String baseUrl = "https://webapps.tekstac.com/AddressBook/";
		driver.get(baseUrl);
		final WebElement heading = driver.findElement(By.xpath("/html/body/center/h2"));

		ExpectedCondition<Boolean> expectation = new
				ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return (heading.getText().equals("Address Book"));
			}
		};

		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(expectation);
	}

	@When("^address details are added$")
	public void testAddressBook(DataTable addressValues) {
		List<List<String>> lis= addressValues.raw();
		driver.findElement(By.id("nickname")).sendKeys(lis.get(1).get(0));
		driver.findElement(By.id("contact")).sendKeys(lis.get(1).get(1));
		driver.findElement(By.id("company")).sendKeys(lis.get(1).get(2));
		driver.findElement(By.id("city")).sendKeys(lis.get(1).get(3));
		driver.findElement(By.id("country")).sendKeys(lis.get(1).get(4));
		driver.findElement(By.id("type")).sendKeys(lis.get(1).get(5));
		driver.findElement(By.id("add")).click();

	}

	@When("^addresses are deleted$")
	public void addresses_are_deleted(DataTable addressValues) throws Exception{
		List<List<String>> data = addressValues.raw();
		text= data.get(1).get(0);
		if("Delete".contains(text)){
			System.out.println("Address Details are deleted ");
		}
	}

	@Then("^all addresses should be displayed to the right$")
	public void all_addresses_should_be_displayed_to_the_right(DataTable expectedAddresses) throws Exception{
		if(driver.findElement(By.xpath("//div[@id='result']/table")).isDisplayed())
		{
			List<List<String>> data = expectedAddresses.raw();
			text= data.get(1).get(0);
			if("Add".contains(text))
			{
				String validText = driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]")).getText();
				System.out.println(validText+ " are displayed");
			}
			if("Edit".contains(text))
			{
				String validText = driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[2]/td[3]")).getText();
				if(validText.equalsIgnoreCase("TCS"))
				{
					System.out.println("Company name updated successfully");
				}
			}
			if("Delete".contains(text)){
				System.out.println("Address Details are deleted ");
			}
		}
	}

	@After
	public void tearDown(){
		driver.close();
		//driver.quit();
	}

}
