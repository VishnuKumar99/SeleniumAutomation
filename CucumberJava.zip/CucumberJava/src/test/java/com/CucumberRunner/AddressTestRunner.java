package com.Cucumber.Cucumber;

import org.junit.runner.RunWith;

import cucumber.api.junit.Cucumber;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\890555\\workspace\\Cucumber\\FeatureFolders\\AddressTest.feature", glue = "stepDefinitions", tags = {"@Delete"})
public class AddressTestRunner {

}