package com.Cucumber.Cucumber;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="C:\\Users\\890555\\workspace\\Cucumber\\FeatureFolders\\Loginwithdata.feature", glue = "stepDefinitions")
public class RunnerClassforloginwithdata {
}
