package com.appium.androidExample;

import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;

public class Calculator {
	static AppiumDriver<MobileElement> driver;

	public static void main(String[] args) throws Exception {
		openCalculator();
	}

	public static void openCalculator() throws Exception {

		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("platformName", "Android");
		cap.setCapability("platformVersion", "12");
		cap.setCapability("udid", "R58N62BWA0F");
		cap.setCapability("deviceName", "Galaxy A51");
		cap.setCapability("appPackage", "com.sec.android.app.popupcalculator");
		cap.setCapability("appActivity", "com.sec.android.app.popupcalculator.Calculator");

		URL url = new URL("http://0.0.0.0:4723/wd/hub");

		driver = new AppiumDriver<MobileElement>(url, cap);
		System.out.println("done");

		// WebElement one =
		// driver.findElement(By.id("com.sec.android.app.popupcalculator:id/bt_01"));

	}
}
