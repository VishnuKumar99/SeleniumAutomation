package com.java.selenium.basics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TableDemo {

	public static void main(String[] args) {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("http://cookbook.seleniumacademy.com/Locators.html");
		driver.manage().window().maximize();
		
		WebElement table            = driver.findElement(By.id("items"));      
		List<WebElement>   rows     =  table.findElements(By.tagName("tr"));
		int n = rows.size();
		System.out.println("Number of rows in the table = "+ n);
		
		//Find the number of columns in the oth row
		List<WebElement> cols0 = rows.get(0).findElements(By.tagName("td"));
		int m = cols0.size();
		System.out.println("Number of columns in the first row = "+ m);
		
		//Get the element at row0, col0
		String value00 = cols0.get(0).getText();
		System.out.println("Value at row0 and column0 = "+ value00);
		
		//Get the element at row0, col0
		String value01 = cols0.get(1).getText();
		System.out.println("Value at row0 and column1 = "+ value01);
		
		//Take for loop for number of rows
		for(int i=0; i<rows.size();i++) {
			List<WebElement> colsi = rows.get(i).findElements(By.tagName("td"));
			for(int j=0; j<colsi.size(); j++) {
				String element = colsi.get(j).getText();
				System.out.print(" "+ element);
			}
			System.out.println();
		}
		
	driver.quit();
		
	}

}
