package com.java.selenium.basics;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowsDemo {

	public static void main(String[] args) throws InterruptedException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver(); 
		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		driver.manage().window().maximize();
		
		//Get the window id and print it
		String windowId = driver.getWindowHandle();
		System.out.println("Window Id of parent window = "+ windowId);
		
		//Click on the Help, Online chat support and Visit Us buttons to get more browser windows.
		driver.findElement(By.id("helpbutton")).click();
		driver.findElement(By.id("chatbutton")).click();
		driver.findElement(By.id("visitbutton")).click();
		//Get the collection of all opened browser windows.
		Set<String> allWindows = driver.getWindowHandles();
		System.out.println("Number of windows opened = "+ allWindows.size());
		// To print all the windowIds
		for(String allWindowsIns : allWindows) {
			System.out.println(allWindowsIns);
		}

		// Find the window whose title is equal to "Visit Us"
		String expTitle = "Visit Us";
		if(!allWindows.isEmpty()) {
			for(String allWindowsIns : allWindows) {
				try {
					String actualTitle = driver.switchTo().window(allWindowsIns).getTitle();
					if(expTitle.equalsIgnoreCase(actualTitle)) {
						System.out.println("Visit Us browser window is found");
						System.out.println("Actual Title = "+ actualTitle);
						driver.close();// Will close the Visit Us browser window.
						break;		 
					}				
			    }catch(NoSuchWindowException nswe) {
				System.out.println(nswe);
			    } 
			} // end of for loop
		} // end of if
		//Navigate to main or parent window and do automation
		driver.switchTo().window(windowId);
		driver.findElement(By.name("abs")).click();
		Thread.sleep(3000);
		driver.quit();

	}// end of main method
}//  end of class
