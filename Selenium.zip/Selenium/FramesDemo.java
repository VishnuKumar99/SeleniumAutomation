package com.java.selenium.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FramesDemo {

	public static void main(String[] args) {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		try {
		WebDriver driver = new ChromeDriver(); 
		driver.get("http://cookbook.seleniumacademy.com/Frames.html");
		driver.manage().window().maximize();
		
		//Move to left frame and do automation.
		try {
			 driver.switchTo().frame("left");
			 WebElement msg = driver.findElement(By.tagName("p"));
			 String text = msg.getText();
			 System.out.println("Message1 = "+ text);
		}catch(NoSuchFrameException  nsfe) {
			System.out.println(nsfe);
		}
		finally {
			driver.switchTo().defaultContent();
		}
		 try {
		 driver.switchTo().frame(1);
		 WebElement msg = driver.findElement(By.tagName("p"));
		 String text = msg.getText();
		 System.out.println("Message2 = "+ text);
		 }catch(NoSuchFrameException  nsfe) {
				System.out.println(nsfe);
		  }
		finally {
			driver.switchTo().defaultContent();
		}
		 
		 try {
			 driver.switchTo().frame("right");
			 WebElement msg = driver.findElement(By.tagName("p"));
			 String text = msg.getText();
			 System.out.println("Message3 = "+ text);
			 }catch(NoSuchFrameException  nsfe) {
					System.out.println(nsfe);
			  }
			finally {
				driver.switchTo().defaultContent();
			}
	    driver.quit();
		}catch(WebDriverException wde) {
			System.out.println(wde);
		}
	}
}
