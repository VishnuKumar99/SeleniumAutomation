package com.java.selenium.basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GoogleTitle {
	public static void main(String[] args) throws InterruptedException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); // driver is an object of type ChromeDriver();
		
		driver.get("https://www.google.com/");
		//driver.manage().window().maximize();
		
		String expectedTitle ="Google";
		String actualTitle   = driver.getTitle();
		
		System.out.println("Actual title = "+ actualTitle);
		
		if(expectedTitle.equalsIgnoreCase(actualTitle))
			System.out.println("Titles are equal. Test case passed");
		else
			System.out.println("Titles are not equal. Test case failed");
		
       Thread.sleep(2500);
	   //close the app
		driver.quit();
	}
}
