package com.java.selenium.basics;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScreenshotDemo {

	public static void main(String[] args) throws IOException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); // driver is an object of type ChromeDriver();
		
		driver.get("https://www.cognizant.com/");
		driver.manage().window().maximize();
		
		Calendar  date  = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd HH-MM-SS");
		String dateNow   = formatter.format(date.getTime());
        System.out.println("Current Date with time = "+ dateNow);
        
        String fileName = "D:\\Temp\\Screenshot38Batch_"+dateNow+".jpeg";
		
		File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scr, new File(fileName));
		
		driver.quit();

	}
}
