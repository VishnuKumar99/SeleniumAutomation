package com.java.selenium.basics;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsDemo {

	public static void main(String[] args) throws InterruptedException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver(); 
		driver.get("http://cookbook.seleniumacademy.com/Alerts.html");
		driver.manage().window().maximize();

		driver.findElement(By.id("simple")).click();
		Alert a;
		a = driver.switchTo().alert();
		String msg = a.getText();
		Thread.sleep(3000);
		a.accept();
		System.out.println("Message of the alert box = "+ msg);
		
		driver.findElement(By.id("confirm")).click();
		
		a = driver.switchTo().alert();
	    msg = a.getText();
		Thread.sleep(3000);
		a.dismiss();
		System.out.println("Message of the alert box = "+ msg);

        driver.findElement(By.id("prompt")).click();
		
		a = driver.switchTo().alert();
	    a.sendKeys("Cognizant");
		Thread.sleep(3000);
		a.accept();
		Thread.sleep(3000);
			
		driver.quit();
	}

}
