package com.java.selenium.basics;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TakingScreenshotsPassedOrFailed {

	public static void main(String[] args) throws InterruptedException, IOException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		driver.manage().window().maximize();
		//Identify email, password, login
		WebElement email    = driver.findElement(By.id("input-email"));
		WebElement passWord = driver.findElement(By.id("input-password"));
		WebElement login    = driver.findElement(By.xpath("//input[@value='Login']"));
		
		email.sendKeys("Jareena@gmail.com");
		passWord.sendKeys("Jareena123");
		login.submit(); // if type="button" or checkbox or radio then click method will work
		                // if type="submit", then obj.submit() will work.
		
		Thread.sleep(3000);
		
		WebElement editYourInfo = driver.findElement(By.linkText("Edit your account information"));
		
		Calendar  date  = Calendar.getInstance();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MMM-dd HH-MM-SS");
		String dateNow   = formatter.format(date.getTime());
		
		String tcName = "LoginCheck";
		String fileName;
		
		if(editYourInfo.isDisplayed()) {
			File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			fileName = "D:\\JavaSeleniumWorkSpace\\A_Cog_Jan_Selenium_38\\PassedScreenShots\\"  + tcName + dateNow+".jpeg";
			FileUtils.copyFile(scr, new File(fileName));
			System.out.println("Login success");
		}
		else {
			File scr = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			fileName = "D:\\JavaSeleniumWorkSpace\\A_Cog_Jan_Selenium_38\\FailedScreenShots\\"  + tcName + dateNow+".jpeg";
			FileUtils.copyFile(scr, new File(fileName));
			System.out.println("Login not success");
		}
		
		driver.quit();			
	}

}
