package com.java.selenium.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OpenCartDemoLogin {

	public static void main(String[] args) throws InterruptedException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); // driver is an object of type ChromeDriver();
		
		driver.get("https://demo.opencart.com/index.php?route=account/login");
		driver.manage().window().maximize();
		try {
		WebDriverWait  wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("input-email")));
		
		driver.findElement(By.id("input-email")).sendKeys("Jareena@gmail.com");
		
		WebElement passWord = driver.findElement(By.id("input-password"));
		WebElement login    = driver.findElement(By.xpath("//input[@value='Login']"));
		
		
		passWord.sendKeys("Jareena123");
		login.submit(); 
		
		WebDriverWait  wait2 = new WebDriverWait(driver, 8);
		wait2.until(ExpectedConditions.presenceOfElementLocated(By.linkText("Edit your account information")));
		
		WebElement editYourInfo = driver.findElement(By.linkText("Edit your account information"));
		
		if(editYourInfo.isDisplayed())
			System.out.println("Login success");
		else
			System.out.println("Login not success");
		}catch(NoSuchElementException nsef) {
			System.out.println(nsef);
		}	
		driver.quit();			
	}
}
