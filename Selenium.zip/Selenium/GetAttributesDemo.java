package com.java.selenium.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class GetAttributesDemo {

	public static void main(String[] args) {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();

		WebElement element = driver.findElement(By.id("email"));
		
		String text = element.getText();
		String tag  = element.getTagName();
		//Class<? extends WebElement> cls  = element.getClass();
		String cls1 = element.getAttribute("class");
		String type = element.getAttribute("type");
		String name = element.getAttribute("name");
		String label = element.getAttribute("aria-label");
		
		//Get CSS attributes
		String bgclr = element.getCssValue("background-color");
		String font  = element.getCssValue("font-family");
		
		System.out.println("Text of email = "+ text);
		System.out.println("Tag of email = "+ tag);
		//System.out.println("Class of email = "+ cls);
		System.out.println("Class of email using get attribute = "+ cls1);
		System.out.println("Type of email = "+ type);
		System.out.println("Name of email = "+ name);
		System.out.println("Label  of email = "+ label);
		
		System.out.println("BG Colour = "+ bgclr);
		System.out.println("Font       = "+ font);
		
		driver.quit();
					
	}
}
