package data;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;


public class ProductsXpath
{
    public static void displayXpath()
    {
	try {
		    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		    DocumentBuilder         db = dbf.newDocumentBuilder();
		    Document                d  = db.parse("src\\data\\Products.xml");
		    XPath xp                   =  XPathFactory.newInstance().newXPath();
		    //Get all the nodes
		    NodeList nl = (NodeList) xp.compile("//product").evaluate(d, XPathConstants.NODESET);
		    System.out.println("Number of nodes = "+nl.getLength());
			for(int i=0; i<nl.getLength();i++)
			{
				Element element = (Element)nl.item(i);
				String str      = element.getAttribute("id");
				System.out.println(str);
				
				//System.out.println("Id : "   +  xp.compile("@id").evaluate(nl.item(i)));
				System.out.println("Name : " +  xp.compile("./name").evaluate(nl.item(i)));
				System.out.println("Price : "+  xp.compile("./price").evaluate(nl.item(i)));	
			}
	 }
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
  }	
}
	

