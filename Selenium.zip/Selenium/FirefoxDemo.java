package com.java.selenium.basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxDemo {

	public static void main(String[] args) throws InterruptedException {
		 String path = ".\\GeckoDriver\\geckodriver.exe";
		 System.setProperty("webdriver.gecko.driver", path);   
		 WebDriver driver = new FirefoxDriver();
		
			driver.get("https://www.google.com/");
			//driver.manage().window().maximize();
			
			String expectedTitle ="Google";
			String actualTitle   = driver.getTitle();
			
			System.out.println("Actual title = "+ actualTitle);
			
			if(expectedTitle.equalsIgnoreCase(actualTitle))
				System.out.println("Titles are equal. Test case passed");
			else
				System.out.println("Titles are not equal. Test case failed");
			
	       Thread.sleep(2500);
		   //close the app
			driver.quit();

	}

}
