package com.java.selenium.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ListBoxDemo {

	public static void main(String[] args) throws InterruptedException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		driver.manage().window().maximize();
	    // Identify the list box 
		Select dropDown = new Select(driver.findElement(By.name("make")));
		int n = dropDown.getOptions().size();
		System.out.println("Number of options = "+ n);
		
		//Find the default option
		String defaultOption = dropDown.getFirstSelectedOption().getText();
		System.out.println("Default Option = " + defaultOption);
			
		//To select Audi
		dropDown.selectByValue("audi");
	//	dropDown.selectByVisibleText("Audi");
	//	dropDown.selectByIndex(2);
		Thread.sleep(3000);
		// true - multi select, false - single select.
		boolean multiStatus = dropDown.isMultiple(); 
		System.out.println("MultiSelect Status of List Box = "+ multiStatus);
		
		//get the text associated with the 2nd option
		String optionText = dropDown.getOptions().get(1).getText();//Mercedes
		System.out.println("Second option = "+ optionText);
		
		//Retrieve all the options into a String array
		String options[] = new String[n]; // int n = dropDown.getOptions().size();
	    for(int i=0; i<n; i++) {
	    	options[i]= dropDown.getOptions().get(i).getText();
	    }
	    //Print the elements in the options array
	    for(String optionsIns : options) {
	    	System.out.println(optionsIns);
	    }		
		driver.quit();	
   }
}
