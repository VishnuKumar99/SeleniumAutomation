package com.java.selenium.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ListBoxMultiSelect {

	public static void main(String[] args) throws InterruptedException {
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); 
		
		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		driver.manage().window().maximize();
	    // Identify the list box 
		Select dropDown = new Select(driver.findElement(By.name("color")));
		int n = dropDown.getOptions().size();
		System.out.println("Number of options = "+ n);
		
		boolean multiStatus = dropDown.isMultiple(); 
		System.out.println("MultiSelect Status of List Box = "+ multiStatus);
		
		//Select White, brown  and silver
		dropDown.selectByVisibleText("White");
		dropDown.selectByVisibleText("Brown");
		dropDown.selectByVisibleText("Silver");
		
		Thread.sleep(3000);
		
		//Find the number of options selected at this moment
		System.out.println("Number of options selected = "+ dropDown.getAllSelectedOptions().size());
		
		//Unselect Brown
		dropDown.deselectByVisibleText("Brown");
		//dropDown.deselectByValue("br");
		//dropDown.deselectByIndex(3);
		
		//Find the number of options selected at this moment
		System.out.println("Number of options selected = "+ dropDown.getAllSelectedOptions().size());
		
		Thread.sleep(3000);
		driver.quit();
		
	}

}
