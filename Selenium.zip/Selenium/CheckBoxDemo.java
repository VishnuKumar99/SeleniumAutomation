package com.java.selenium.basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxDemo {

	public static void main(String[] args) throws InterruptedException {
		
		String path=".\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		
		//Create the driver instance for Chrome
		WebDriver driver = new ChromeDriver(); // driver is an object of type ChromeDriver();
		
		driver.get("http://cookbook.seleniumacademy.com/Config.html");
		driver.manage().window().maximize();
		
		WebElement diesel = driver.findElement(By.xpath("//input[@value='Diesel']"));
		if(!diesel.isSelected()) {
			diesel.click();
		}
		
		// Identify the Check box and click on check box
		WebElement airBags = driver.findElement(By.name("airbags"));
		if(!airBags.isSelected())
		   airBags.click();
		Thread.sleep(4000);
		driver.quit();		
  }
}
