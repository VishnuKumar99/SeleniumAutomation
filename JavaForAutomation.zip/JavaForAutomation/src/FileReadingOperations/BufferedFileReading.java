package FileReadingOperations;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedFileReading {

	public static void main(String[] args) throws IOException {
		String location = "UsingBufferedWriter.txt";

		FileReader files = new FileReader(location);
		BufferedReader reader = new BufferedReader(files);
		String currentLine = reader.readLine();
		System.out.println(currentLine);

	}

}
