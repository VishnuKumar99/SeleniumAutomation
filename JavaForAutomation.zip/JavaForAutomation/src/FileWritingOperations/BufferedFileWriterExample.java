package FileWritingOperations;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedFileWriterExample {

	public static void main(String[] args) throws IOException {
		String location = "UsingBufferedWriter.txt";
		String content = "This is Java file writing example text 2";

		FileWriter file = new FileWriter(location);
		BufferedWriter buffer = new BufferedWriter(file);

		buffer.write(content);
		buffer.close();

	}

}
