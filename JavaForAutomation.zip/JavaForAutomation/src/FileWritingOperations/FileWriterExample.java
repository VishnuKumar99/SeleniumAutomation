package FileWritingOperations;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterExample {

	public static void main(String[] args) throws IOException {
		String location = "UsingFileWriter.txt";
		String content = "This is Java file writing example text 1";

		FileWriter file = new FileWriter(location);
		file.write(content);
		file.close();
	}

}
