package FileWritingOperations;

import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamExample {

	public static void main(String[] args) throws IOException {
		String location = "UsingFOS.txt";
		String content = "This is Java file writing example text 3";

		FileOutputStream FOS = new FileOutputStream(location);
		byte[] writeThis = content.getBytes();

		FOS.write(writeThis);
		FOS.close();

	}

}
