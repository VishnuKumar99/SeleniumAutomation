package JsonWriting;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class JsonWritingExample {

	public static void main(String[] args) throws IOException {

		JSONObject jsonObject = new JSONObject();
		jsonObject.put("Name", "VishnuKumar");
		jsonObject.put("Age", 1);
		// [ " magical smile " , " magnetic eyes " ]
		JSONArray array = new JSONArray();
		array.add("magical smile");
		array.add("magnetic eyes");

		jsonObject.put("Special Qualities", array);

		FileWriter fileWriter = new FileWriter("Vishnu.json");
		fileWriter.write(jsonObject.toJSONString());
		fileWriter.close();

	}

}
