package Anotations;

import org.testng.annotations.Test;

public class TestAnnotation {
		
	  @Test
	  public void testMethod() {
		  
		  System.out.println("This is a test method");
		  
	  }
	}

