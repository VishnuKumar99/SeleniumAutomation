package Anotations;

import org.testng.annotations.Test;

public class TestAnnotaionByClass {
	@Test
	public void myTest() {
		System.out.println(" I am in test .");
	}
	
}
