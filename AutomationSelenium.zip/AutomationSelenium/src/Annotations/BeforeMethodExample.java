package Anotations;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BeforeMethodExample {
	  @Test
	  public void TestMethod() {
		  System.out.println(" I am inside Test method");
	  }
	  @Test
	  public void TestMethodTwo() {
		  System.out.println(" I am inside Test method Two");
	  }
	  @BeforeMethod
	  public void myBeforeMethod() {
		  System.out.println(" I am inside my Before method");
	  }

	}

